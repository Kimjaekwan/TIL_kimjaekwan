#polite : 예의바른
#Print() 함수를 통해
#인사를 열 번 하는 코드를 작성해 주세요

"""
polite = '안녕하세요'
while len(polite) > 50:
    polite = polite + polite
예의바른 = polite
print(예의바른)
"""

hi = '안녕하세요!'

#for : 특정 범위까지 해당 문법을 반복 실행함
for i in range(0,10):
    # 0 ~ 9까지의 반복을 실행합니다.
    print(hi)