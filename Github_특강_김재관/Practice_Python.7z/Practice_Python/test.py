tree = '나무'
bulb = '전구'
deco = '장식'
while len(tree) > 20:
    tree = tree + bulb + deco
christmas_tree = tree
print(christmas_tree)