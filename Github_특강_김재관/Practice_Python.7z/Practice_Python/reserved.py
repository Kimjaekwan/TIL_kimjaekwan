while = '반복문'
print(while)