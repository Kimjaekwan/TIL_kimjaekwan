tree = '나무'
deco = '장식'
#while 특정 조건까지 해당 문법을 반복 실행함
while len(tree) < 20:
    tree = tree + deco
christmas_tree = tree
print(christmas_tree)
